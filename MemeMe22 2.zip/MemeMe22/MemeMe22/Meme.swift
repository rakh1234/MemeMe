//
//  Meme.swift
//  MemeMe22
//
//  Created by Razan on 09/01/2021.
import Foundation
import UIKit

struct Meme {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memeImage: UIImage
}
