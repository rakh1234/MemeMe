//
//  MemeCollectionViewCell.swift
//  MemeMe22
//
//  Created by Razan on 09/01/2021.
//
import Foundation
import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var memeImageView: UIImageView!
}
