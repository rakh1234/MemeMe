//
//  MemeViewController.swift
//  MemeMe22
//
//  Created by Razan on 09/01/2021.
//
import Foundation
import UIKit

class MemeViewController: UIViewController {
    
    var meme: Meme!
    
    @IBOutlet weak var memeImageVIew: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.memeImageVIew!.image = meme.memeImage
    }
}
